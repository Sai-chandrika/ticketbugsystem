package com.example.ticket_bug_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketBugSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketBugSystemApplication.class, args);
	}

}
