package com.example.ticket_bug_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketBugSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
