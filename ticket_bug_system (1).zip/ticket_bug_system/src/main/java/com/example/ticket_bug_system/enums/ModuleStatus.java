package com.example.ticket_bug_system.enums;

/**
 * @author chandrika.g
 * user
 * @ProjectName ticket_bug_system
 * @since 06-10-2023
 */
public enum ModuleStatus {
    WAITING,//0
    HOLD,//1
    IN_PROGRESS,//2
    COMPLETED//3
}
